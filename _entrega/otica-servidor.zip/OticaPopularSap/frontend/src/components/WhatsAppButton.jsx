import './WhatsAppButton.css'

const WHATSAPP_NUMBER = '5543996335759'

function WhatsAppButton() {
  return (
    <a
      className="whatsapp-fab"
      href={`https://wa.me/${WHATSAPP_NUMBER}`}
      target="_blank"
      rel="noreferrer"
      aria-label="Falar no WhatsApp"
    >
      <svg viewBox="0 0 32 32" width="26" height="26" aria-hidden="true">
        <path
          fill="currentColor"
          d="M16.02 3C9.4 3 4 8.4 4 15.02c0 2.2.58 4.28 1.68 6.14L4 29l8.02-1.66a12.9 12.9 0 0 0 4 .63c6.62 0 12.02-5.4 12.02-12.02C28.04 8.4 22.64 3 16.02 3m0 21.9c-1.35 0-2.68-.36-3.85-1.05l-.28-.16-4.76.98.99-4.65-.18-.29a9.83 9.83 0 0 1-1.5-5.21c0-5.43 4.42-9.85 9.86-9.85 5.43 0 9.85 4.42 9.85 9.85s-4.42 9.38-9.85 9.38m5.4-7.38c-.3-.15-1.75-.86-2.02-.96-.27-.1-.47-.15-.67.15s-.77.96-.94 1.16-.35.22-.64.07a8.07 8.07 0 0 1-4.02-3.52c-.3-.52.3-.48.87-1.6.1-.2.05-.37-.02-.52-.07-.15-.67-1.61-.91-2.2-.24-.58-.49-.5-.67-.51h-.57c-.2 0-.52.07-.79.37s-1.05 1.02-1.05 2.5 1.07 2.9 1.22 3.1c.15.2 2.1 3.2 5.08 4.49.71.31 1.26.49 1.69.62.71.23 1.36.2 1.87.12.57-.08 1.75-.71 2-1.4.24-.68.24-1.27.17-1.4-.07-.13-.27-.2-.57-.35"
        />
      </svg>
      {/* a dica só aparece no desktop (mouse ou foco); o leitor de tela já tem o aria-label */}
      <span className="whatsapp-fab__dica" aria-hidden="true">
        Fale conosco
      </span>
    </a>
  )
}

export default WhatsAppButton
