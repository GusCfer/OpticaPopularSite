import Hero from '../components/Hero'
import Destaques from '../components/Destaques'
import Features from '../components/Features'
import Testimonials from '../components/Testimonials'
import Contact from '../components/Contact'

function Home() {
  return (
    <>
      <Hero />
      <Destaques />
      <Features />
      <Testimonials />
      <Contact />
    </>
  )
}

export default Home
