import { useEffect, useState } from 'react'
import { api, formatarPreco } from '../services/api'
import './Destaques.css'

function Destaques() {
  const [produtos, setProdutos] = useState([])
  const [carregando, setCarregando] = useState(true)

  useEffect(() => {
    let ativo = true
    api
      .destaques()
      .then((lista) => ativo && setProdutos(lista))
      .catch(() => ativo && setProdutos([]))
      .finally(() => ativo && setCarregando(false))
    return () => {
      ativo = false
    }
  }, [])

  // Sem destaques cadastrados (ou API fora do ar) a seção simplesmente não aparece.
  if (carregando || produtos.length === 0) return null

  return (
    <section id="destaques" className="section destaques">
      <div className="container">
        <div className="section-head center">
          <span className="eyebrow">Selecionados para você</span>
          <h2>Destaques da loja</h2>
          <p>Peças escolhidas a dedo pela nossa equipe. Passe na loja para experimentar.</p>
        </div>

        <div className="destaques__grid">
          {produtos.map((produto) => (
            <article className="produto-card" key={produto.id}>
              <div className="produto-card__midia">
                {produto.imagemUrl ? (
                  <img src={produto.imagemUrl} alt={produto.nome} loading="lazy" />
                ) : (
                  <span className="produto-card__sem-foto">Sem foto</span>
                )}
                <span className="produto-card__tag">{produto.categoria?.nome}</span>
              </div>

              <div className="produto-card__corpo">
                {produto.marca && <span className="produto-card__marca">{produto.marca}</span>}
                <h3>{produto.nome}</h3>
                {produto.descricao && <p className="produto-card__desc">{produto.descricao}</p>}

                <div className="produto-card__preco">
                  {produto.precoPromocional ? (
                    <>
                      <span className="produto-card__preco-antigo">
                        {formatarPreco(produto.preco)}
                      </span>
                      <strong>{formatarPreco(produto.precoPromocional)}</strong>
                    </>
                  ) : (
                    <strong>{formatarPreco(produto.preco)}</strong>
                  )}
                </div>

                <a
                  className="btn btn-dark produto-card__cta"
                  href={`https://wa.me/5543996335759?text=${encodeURIComponent(
                    `Olá! Tenho interesse no produto: ${produto.nome}`
                  )}`}
                  target="_blank"
                  rel="noreferrer"
                >
                  Tenho interesse
                </a>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  )
}

export default Destaques
